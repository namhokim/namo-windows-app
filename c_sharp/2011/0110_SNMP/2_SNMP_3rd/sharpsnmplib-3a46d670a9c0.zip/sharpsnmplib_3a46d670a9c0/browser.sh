cd Browser/bin/Debug
mono Browser.exe
