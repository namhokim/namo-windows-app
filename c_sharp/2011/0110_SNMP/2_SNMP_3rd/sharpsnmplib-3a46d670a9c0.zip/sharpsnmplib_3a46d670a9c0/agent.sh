cd snmpd/bin/Debug
echo "need to run as root for port smaller than 1024" 
mono snmpd.exe
