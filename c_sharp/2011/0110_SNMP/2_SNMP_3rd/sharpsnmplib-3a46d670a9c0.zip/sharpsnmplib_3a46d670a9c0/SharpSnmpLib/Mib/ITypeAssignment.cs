﻿namespace Lextm.SharpSnmpLib.Mib
{
    internal interface ITypeAssignment : IConstruct
    {
    }
}
