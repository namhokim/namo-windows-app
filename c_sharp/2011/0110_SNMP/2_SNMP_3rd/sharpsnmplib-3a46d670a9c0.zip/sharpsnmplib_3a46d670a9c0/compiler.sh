cd Compiler/bin/Debug
mono Compiler.exe
