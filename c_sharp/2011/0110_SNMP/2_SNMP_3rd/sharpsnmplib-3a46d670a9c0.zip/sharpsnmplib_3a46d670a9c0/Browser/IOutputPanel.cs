namespace Lextm.SharpSnmpLib
{
    internal interface IOutputPanel
    {
        void Write(string message);
    }
}